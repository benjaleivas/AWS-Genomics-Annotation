#!/bin/bash
source /home/ec2-user/mpcs-cc/venv/bin/activate
python /home/ec2-user/mpcs-cc/ann/annotator.py


